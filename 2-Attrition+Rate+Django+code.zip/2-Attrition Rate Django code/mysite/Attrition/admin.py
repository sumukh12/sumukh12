from django.contrib import admin
from .models import Attrition_table

# Register your models here.
admin.site.register(Attrition_table)
